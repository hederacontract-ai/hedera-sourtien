# Design Guidelines for HederaSoutien

## Design Approach

**Hybrid Reference Approach**: Drawing inspiration from GoFundMe (emotional storytelling + transparency), Stripe (trust through clarity), and accessibility leaders like gov.uk for inclusive design patterns.

**Core Principle**: Dignity through design - create an empowering, transparent platform that treats all users with respect while making complex blockchain technology approachable.

## Typography System

**Font Families** (via Google Fonts):
- **Primary**: Inter (400, 500, 600, 700) - exceptional readability, supports accessibility
- **Accent**: Poppins (600, 700) - for headlines and emotional moments

**Type Scale**:
- Hero Headlines: text-5xl md:text-6xl (Poppins, 700)
- Page Titles: text-3xl md:text-4xl (Poppins, 600)
- Section Headers: text-2xl md:text-3xl (Inter, 600)
- Card Titles: text-xl (Inter, 600)
- Body Text: text-base md:text-lg (Inter, 400) - larger for accessibility
- Metadata/Labels: text-sm (Inter, 500)
- Micro-copy: text-xs (Inter, 400)

**Line Height**: Use relaxed (1.625) for all body text to aid readability

## Layout System

**Spacing Units**: Consistent use of Tailwind units - 4, 6, 8, 12, 16, 24, 32 for vertical rhythm
- Component padding: p-6 to p-8
- Section spacing: py-16 to py-24
- Card gaps: gap-6 to gap-8

**Container Strategy**:
- Marketing pages: max-w-7xl
- Dashboard content: max-w-6xl
- Forms and text content: max-w-2xl
- Wide data tables: max-w-screen-xl

**Grid Patterns**:
- Assistance requests: grid-cols-1 md:grid-cols-2 lg:grid-cols-3
- Dashboard metrics: grid-cols-2 md:grid-cols-4
- User types (homepage): grid-cols-1 md:grid-cols-2
- Equipment gallery: grid-cols-2 md:grid-cols-3 lg:grid-cols-4

## Component Library

### Navigation
- **Header**: Sticky navigation with clear user type indicator, wallet status, and accessibility controls (font size toggle, contrast mode)
- **User type badge**: Visible indicator (Donor/Beneficiary/Volunteer) with icon
- **Main nav**: Horizontal on desktop, hamburger on mobile with large touch targets (min 44px)

### Cards & Content Blocks

**Assistance Request Cards**:
- Large touch-friendly cards with clear urgency indicators
- Progress bars for funding goals with accessible labels
- Beneficiary profile photo (if provided) with respectful placeholder alternative
- Category icons using Heroicons
- Clear CTA buttons with action-oriented language

**Donor Badge Display**:
- NFT badge showcases with tier progression visual
- Celebratory gradient treatments for achievements
- Transaction history with blockchain explorer links
- Impact metrics (people helped, equipment donated)

**Equipment Registry Cards**:
- High-quality product images with detailed alt text
- Ownership history timeline
- Condition indicators with clear visual coding
- Transfer NFT functionality with confirmation modals

### Forms
- **Input fields**: Large (h-12), clear labels above inputs, helpful placeholder text
- **Error states**: Inline validation with icon + message below field
- **Success states**: Green checkmark with confirmation message
- **Required indicators**: Asterisk (*) with "Champs obligatoires" legend
- **Multi-step forms**: Progress indicator at top, clear back/next navigation

### Dashboards

**Beneficiary Dashboard**:
- Welcoming hero section with personalized greeting
- Quick action cards: "Express a Need", "View Messages", "My Profile"
- Active requests feed with status badges
- Received support timeline with donor recognition

**Donor Dashboard**:
- Impact summary cards (total donated, people helped, NFT badges earned)
- Browse needs section with smart filters (urgency, category, location)
- Recent transactions with Hedera verification links
- NFT badge showcase gallery

**Volunteer Dashboard**:
- Available opportunities feed
- Skills certification display
- Hours logged tracker
- Impact stories carousel

### Transparency Elements
- **Transaction blocks**: Card-based with Hedera transaction ID, timestamp, amounts, and direct HashScan link
- **Fund flow diagrams**: Visual representation of donation journey
- **Impact metrics**: Large numbers with context (e.g., "127 personnes aidées")

### Messaging System
- Chat-style interface with clear sender/receiver distinction
- Thread grouping by assistance request
- Unread badges with accessible announcements
- Attachment support for documents/photos

### Accessibility Features
- **Keyboard navigation**: Clear focus states (ring-2 ring-offset-2)
- **Skip links**: "Skip to main content" prominent at top
- **ARIA labels**: Comprehensive labeling for all interactive elements
- **Contrast modes**: Toggle for high contrast theme
- **Font scaling**: User-controlled text size adjustment
- **Screen reader announcements**: For dynamic content updates

## Page-Specific Layouts

### Homepage
- **Hero**: Full-width hero with large headline "Chaque besoin compte, chaque aide aussi", two large CTA buttons (Je suis une personne handicapée / Je suis un partenaire)
- **How it Works**: 3-column grid explaining the process with icons
- **Impact Stats**: 4-column metrics showcase (personnes aidées, dons collectés, équipements partagés, bénévoles actifs)
- **Recent Success Stories**: Carousel of testimonials with photos
- **Platform Features**: 2-column split highlighting Hedera transparency
- **Trust Indicators**: Logos of partner associations, blockchain verification badge

### Registration Pages
- **Split layout**: Left side with welcoming illustration, right side with form
- **Single column form**: Clear field grouping (Personal Info, Disability Info, Account Setup)
- **Progressive disclosure**: Show relevant fields based on user type selection
- **Accessibility note**: Prominent message about platform's commitment to accessibility

### Assistance Request Page
- **Full-width header**: Request title, urgency badge, category tag
- **3-column layout** (desktop): Main content + Sidebar (Beneficiary profile + Support CTA)
- **Rich description**: Formatted text with embedded images if provided
- **Progress section**: Funding goal, amount raised, supporter count
- **Blockchain verification**: Hedera transaction log if applicable
- **Support CTA**: Sticky on mobile, fixed sidebar on desktop

### NFT Gallery/Wallet
- **Masonry grid**: Showcasing all earned NFTs with hover reveal of details
- **Filter bar**: By collection (Donor Badges, Equipment, Certificates)
- **Individual NFT modal**: Full metadata display, blockchain verification, share functionality
- **Achievement timeline**: Chronological acquisition with milestones

## Images

### Hero Images
- **Homepage hero**: Inspiring image showing community support - people of diverse abilities collaborating or supporting each other, warm and hopeful mood
- **Registration pages**: Illustrative graphics showing the user journey, welcoming and inclusive

### Profile & Content
- **User avatars**: Circular, consistent sizing (w-12 h-12 for small, w-24 h-24 for profiles), respectful placeholder for those without photos
- **Equipment photos**: High-quality product images, multiple angles in galleries
- **Success stories**: Authentic photos of beneficiaries and donors (with consent), showing real impact

### NFT Badges
- **Badge designs**: Distinctive visual designs for each tier (Bronze/Silver/Gold/Diamond/Legendary) with celebratory treatments
- **Equipment NFTs**: Product photos with certificate/authenticity overlay
- **Volunteer certificates**: Professional certificate-style designs with SoutienHandi branding

### Illustrations
- **Empty states**: Friendly illustrations for no assistance requests, no messages, etc.
- **Onboarding**: Step-by-step visual guides for first-time users
- **How it works**: Icon-based illustrations explaining the platform process

**Image Treatment**: All images should convey dignity, hope, and empowerment - avoid pity-focused imagery. Use authentic photography over stock photos where possible.