import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp, boolean, pgEnum, jsonb, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Enums
export const userTypeEnum = pgEnum("user_type", ["beneficiary", "donor", "volunteer", "association"]);
export const urgencyLevelEnum = pgEnum("urgency_level", ["low", "medium", "high", "critical"]);
export const requestStatusEnum = pgEnum("request_status", ["active", "funded", "completed", "closed"]);
export const equipmentConditionEnum = pgEnum("equipment_condition", ["excellent", "good", "fair", "needs_repair"]);
export const nftTierEnum = pgEnum("nft_tier", ["bronze", "silver", "gold", "diamond", "legendary"]);

// Session storage table - required for Replit Auth
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// Users table - compatible with Replit Auth
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  userType: userTypeEnum("user_type"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// User profiles - extended information
export const profiles = pgTable("profiles", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  fullName: text("full_name").notNull(),
  email: text("email").notNull(),
  phone: text("phone"),
  avatarUrl: text("avatar_url"),
  bio: text("bio"),
  location: text("location"),
  // Beneficiary specific
  disabilityType: text("disability_type"),
  assistanceNeeds: text("assistance_needs").array(),
  // Donor specific
  totalDonated: integer("total_donated").default(0),
  donationCount: integer("donation_count").default(0),
  // Volunteer specific
  skills: text("skills").array(),
  availability: text("availability"),
  hoursLogged: integer("hours_logged").default(0),
  // Association specific
  organizationName: text("organization_name"),
  registrationNumber: text("registration_number"),
  // Hedera wallet info
  hederaAccountId: text("hedera_account_id"),
  hederaPublicKey: text("hedera_public_key"),
  hederaPrivateKey: text("hedera_private_key"), // Encrypted private key
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Assistance requests
export const assistanceRequests = pgTable("assistance_requests", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  beneficiaryId: varchar("beneficiary_id").notNull().references(() => users.id),
  title: text("title").notNull(),
  description: text("description").notNull(),
  category: text("category").notNull(), // "medical", "equipment", "housing", "education", "employment", "other"
  urgencyLevel: urgencyLevelEnum("urgency_level").notNull(),
  fundingGoal: integer("funding_goal").notNull(), // in cents
  currentAmount: integer("current_amount").default(0).notNull(),
  status: requestStatusEnum("status").default("active").notNull(),
  imageUrls: text("image_urls").array(),
  supporterCount: integer("supporter_count").default(0),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Donations
export const donations = pgTable("donations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  donorId: varchar("donor_id").notNull().references(() => users.id),
  requestId: varchar("request_id").notNull().references(() => assistanceRequests.id),
  amount: integer("amount").notNull(), // in cents
  message: text("message"),
  isAnonymous: boolean("is_anonymous").default(false),
  hederaTransactionId: text("hedera_transaction_id"),
  hederaTransactionUrl: text("hedera_transaction_url"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Equipment registry
export const equipment = pgTable("equipment", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  ownerId: varchar("owner_id").notNull().references(() => users.id),
  name: text("name").notNull(),
  description: text("description").notNull(),
  category: text("category").notNull(), // "wheelchair", "hearing_aid", "walker", "prosthetic", "other"
  condition: equipmentConditionEnum("condition").notNull(),
  imageUrls: text("image_urls").array(),
  purchaseDate: timestamp("purchase_date"),
  estimatedValue: integer("estimated_value"), // in cents
  isAvailableForLoan: boolean("is_available_for_loan").default(false),
  nftTokenId: text("nft_token_id"),
  nftSerialNumber: text("nft_serial_number"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Equipment transfer history
export const equipmentTransfers = pgTable("equipment_transfers", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  equipmentId: varchar("equipment_id").notNull().references(() => equipment.id),
  fromUserId: varchar("from_user_id").notNull().references(() => users.id),
  toUserId: varchar("to_user_id").notNull().references(() => users.id),
  transferDate: timestamp("transfer_date").defaultNow().notNull(),
  hederaTransactionId: text("hedera_transaction_id"),
  notes: text("notes"),
});

// NFT Badges (donor recognition)
export const nftBadges = pgTable("nft_badges", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  tier: nftTierEnum("tier").notNull(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  imageUrl: text("image_url").notNull(),
  nftTokenId: text("nft_token_id"),
  nftSerialNumber: text("nft_serial_number"),
  achievementDate: timestamp("achievement_date").defaultNow().notNull(),
  metadata: text("metadata"), // JSON string for additional data
});

// Messages
export const messages = pgTable("messages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  senderId: varchar("sender_id").notNull().references(() => users.id),
  recipientId: varchar("recipient_id").notNull().references(() => users.id),
  requestId: varchar("request_id").references(() => assistanceRequests.id), // optional - link to specific request
  content: text("content").notNull(),
  isRead: boolean("is_read").default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Volunteer opportunities
export const volunteerOpportunities = pgTable("volunteer_opportunities", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  creatorId: varchar("creator_id").notNull().references(() => users.id), // association or beneficiary
  title: text("title").notNull(),
  description: text("description").notNull(),
  skillsRequired: text("skills_required").array(),
  location: text("location"),
  estimatedHours: integer("estimated_hours"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Volunteer assignments
export const volunteerAssignments = pgTable("volunteer_assignments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  opportunityId: varchar("opportunity_id").notNull().references(() => volunteerOpportunities.id),
  volunteerId: varchar("volunteer_id").notNull().references(() => users.id),
  status: text("status").notNull(), // "pending", "accepted", "completed", "cancelled"
  hoursCompleted: integer("hours_completed").default(0),
  startedAt: timestamp("started_at"),
  completedAt: timestamp("completed_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertProfileSchema = createInsertSchema(profiles).omit({
  id: true,
  createdAt: true,
  totalDonated: true,
  donationCount: true,
  hoursLogged: true,
});

export const insertAssistanceRequestSchema = createInsertSchema(assistanceRequests).omit({
  id: true,
  currentAmount: true,
  supporterCount: true,
  status: true,
  createdAt: true,
  updatedAt: true,
});

export const insertDonationSchema = createInsertSchema(donations).omit({
  id: true,
  createdAt: true,
  hederaTransactionId: true,
  hederaTransactionUrl: true,
});

export const insertEquipmentSchema = createInsertSchema(equipment).omit({
  id: true,
  createdAt: true,
  nftTokenId: true,
  nftSerialNumber: true,
});

export const insertMessageSchema = createInsertSchema(messages).omit({
  id: true,
  isRead: true,
  createdAt: true,
});

export const insertVolunteerOpportunitySchema = createInsertSchema(volunteerOpportunities).omit({
  id: true,
  isActive: true,
  createdAt: true,
});

export const insertVolunteerAssignmentSchema = createInsertSchema(volunteerAssignments).omit({
  id: true,
  hoursCompleted: true,
  createdAt: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type UpsertUser = typeof users.$inferInsert;

export type InsertProfile = z.infer<typeof insertProfileSchema>;
export type Profile = typeof profiles.$inferSelect;

export type InsertAssistanceRequest = z.infer<typeof insertAssistanceRequestSchema>;
export type AssistanceRequest = typeof assistanceRequests.$inferSelect;

export type InsertDonation = z.infer<typeof insertDonationSchema>;
export type Donation = typeof donations.$inferSelect;

export type InsertEquipment = z.infer<typeof insertEquipmentSchema>;
export type Equipment = typeof equipment.$inferSelect;

export type InsertMessage = z.infer<typeof insertMessageSchema>;
export type Message = typeof messages.$inferSelect;

export type InsertVolunteerOpportunity = z.infer<typeof insertVolunteerOpportunitySchema>;
export type VolunteerOpportunity = typeof volunteerOpportunities.$inferSelect;

export type InsertVolunteerAssignment = z.infer<typeof insertVolunteerAssignmentSchema>;
export type VolunteerAssignment = typeof volunteerAssignments.$inferSelect;

export type NFTBadge = typeof nftBadges.$inferSelect;
export type EquipmentTransfer = typeof equipmentTransfers.$inferSelect;
