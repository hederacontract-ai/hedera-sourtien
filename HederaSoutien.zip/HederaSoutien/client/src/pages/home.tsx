import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";
import { 
  Heart, 
  Users, 
  Package, 
  HandHelping, 
  Shield, 
  Zap,
  TrendingUp,
  Award,
  CheckCircle2,
  ArrowRight
} from "lucide-react";

export default function Home() {
  const { data: stats } = useQuery({
    queryKey: ["/api/stats"],
  });

  const features = [
    {
      icon: Shield,
      title: "Transparence Blockchain",
      description: "Chaque don est enregistré sur Hedera pour une traçabilité totale",
    },
    {
      icon: Award,
      title: "Reconnaissance NFT",
      description: "Les donateurs reçoivent des badges NFT pour célébrer leur générosité",
    },
    {
      icon: Package,
      title: "Registre d'Équipements",
      description: "Partagez et suivez les équipements médicaux avec des NFTs",
    },
    {
      icon: HandHelping,
      title: "Réseau de Bénévoles",
      description: "Connectez-vous avec des bénévoles prêts à aider",
    },
  ];

  const howItWorks = [
    {
      step: "1",
      title: "Créez votre profil",
      description: "Inscrivez-vous en tant que bénéficiaire, donateur, bénévole ou association",
    },
    {
      step: "2",
      title: "Exprimez vos besoins ou offrez votre aide",
      description: "Les bénéficiaires publient leurs demandes, les autres répondent",
    },
    {
      step: "3",
      title: "Transactions transparentes",
      description: "Tous les dons sont enregistrés sur la blockchain Hedera",
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b bg-background/95 backdrop-blur">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <Link href="/" data-testid="link-home">
            <div className="flex items-center gap-2 hover-elevate rounded-md p-2 -ml-2" data-testid="logo">
              <Heart className="h-6 w-6 text-primary" />
              <span className="font-semibold text-xl" style={{ fontFamily: "Poppins, sans-serif" }}>
                HederaSoutien
              </span>
            </div>
          </Link>
          
          <nav className="hidden md:flex items-center gap-6">
            <Link href="#fonctionnalites" data-testid="link-features">
              <span className="text-sm font-medium hover:text-primary transition-colors">
                Fonctionnalités
              </span>
            </Link>
            <Link href="#comment-ca-marche" data-testid="link-how-it-works">
              <span className="text-sm font-medium hover:text-primary transition-colors">
                Comment ça marche
              </span>
            </Link>
            <Link href="#impact" data-testid="link-impact">
              <span className="text-sm font-medium hover:text-primary transition-colors">
                Notre impact
              </span>
            </Link>
          </nav>
          
          <div className="flex items-center gap-2">
            <Link href="/login" data-testid="link-login">
              <Button variant="ghost" data-testid="button-login">
                Connexion
              </Button>
            </Link>
            <Link href="/register" data-testid="link-register">
              <Button data-testid="button-register">
                S'inscrire
              </Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 md:py-32 bg-gradient-to-b from-background to-muted/20">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center space-y-8">
            <Badge variant="secondary" className="mb-4" data-testid="badge-powered-by">
              <Zap className="h-3 w-3 mr-1" />
              Propulsé par Hedera Blockchain
            </Badge>
            
            <h1 
              className="text-4xl md:text-6xl font-bold leading-tight"
              style={{ fontFamily: "Poppins, sans-serif" }}
              data-testid="text-hero-title"
            >
              Chaque besoin compte,<br />
              <span className="text-primary">chaque aide aussi</span>
            </h1>
            
            <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
              Une plateforme de solidarité transparente qui connecte les personnes en situation de handicap 
              avec les donateurs et bénévoles. Ensemble, créons un monde plus inclusif.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
              <Link href="/register?type=beneficiary" data-testid="link-register-beneficiary">
                <Button size="lg" className="w-full sm:w-auto" data-testid="button-beneficiary">
                  <Users className="mr-2 h-5 w-5" />
                  Je suis bénéficiaire
                </Button>
              </Link>
              <Link href="/register?type=donor" data-testid="link-register-donor">
                <Button size="lg" variant="outline" className="w-full sm:w-auto" data-testid="button-donor">
                  <Heart className="mr-2 h-5 w-5" />
                  Je veux aider
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      {stats && (
        <section id="impact" className="py-16 border-y bg-card">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
              <div className="text-center" data-testid="stat-users">
                <div className="text-3xl md:text-4xl font-bold text-primary" style={{ fontFamily: "Poppins, sans-serif" }}>
                  {stats.totalUsers}
                </div>
                <div className="text-sm text-muted-foreground mt-2">
                  Utilisateurs actifs
                </div>
              </div>
              <div className="text-center" data-testid="stat-donated">
                <div className="text-3xl md:text-4xl font-bold text-primary" style={{ fontFamily: "Poppins, sans-serif" }}>
                  {(stats.totalDonated / 100).toFixed(0)}€
                </div>
                <div className="text-sm text-muted-foreground mt-2">
                  Dons collectés
                </div>
              </div>
              <div className="text-center" data-testid="stat-equipment">
                <div className="text-3xl md:text-4xl font-bold text-primary" style={{ fontFamily: "Poppins, sans-serif" }}>
                  {stats.equipmentShared}
                </div>
                <div className="text-sm text-muted-foreground mt-2">
                  Équipements partagés
                </div>
              </div>
              <div className="text-center" data-testid="stat-requests">
                <div className="text-3xl md:text-4xl font-bold text-primary" style={{ fontFamily: "Poppins, sans-serif" }}>
                  {stats.activeRequests}
                </div>
                <div className="text-sm text-muted-foreground mt-2">
                  Besoins actifs
                </div>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* How It Works */}
      <section id="comment-ca-marche" className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 
              className="text-3xl md:text-4xl font-bold mb-4"
              style={{ fontFamily: "Poppins, sans-serif" }}
              data-testid="text-how-it-works-title"
            >
              Comment ça marche ?
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Un processus simple et transparent pour créer un impact réel
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {howItWorks.map((item, index) => (
              <Card key={index} className="text-center" data-testid={`card-how-it-works-${index}`}>
                <CardHeader>
                  <div className="mx-auto w-12 h-12 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-xl font-bold mb-4">
                    {item.step}
                  </div>
                  <CardTitle className="text-xl">{item.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-base">
                    {item.description}
                  </CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section id="fonctionnalites" className="py-20 bg-muted/20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 
              className="text-3xl md:text-4xl font-bold mb-4"
              style={{ fontFamily: "Poppins, sans-serif" }}
              data-testid="text-features-title"
            >
              Pourquoi HederaSoutien ?
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Une plateforme moderne qui allie technologie blockchain et impact social
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto">
            {features.map((feature, index) => (
              <Card key={index} className="hover-elevate" data-testid={`card-feature-${index}`}>
                <CardHeader>
                  <feature.icon className="h-10 w-10 text-primary mb-4" />
                  <CardTitle className="text-lg">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription>
                    {feature.description}
                  </CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-primary text-primary-foreground">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center space-y-6">
            <h2 
              className="text-3xl md:text-4xl font-bold"
              style={{ fontFamily: "Poppins, sans-serif" }}
              data-testid="text-cta-title"
            >
              Rejoignez notre communauté
            </h2>
            <p className="text-lg opacity-90">
              Que vous ayez besoin d'aide ou que vous souhaitiez aider les autres, 
              il y a une place pour vous sur HederaSoutien.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
              <Link href="/register" data-testid="link-cta-register">
                <Button 
                  size="lg" 
                  variant="secondary" 
                  className="w-full sm:w-auto"
                  data-testid="button-cta-register"
                >
                  Créer un compte
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
              <Link href="/requests" data-testid="link-cta-browse">
                <Button 
                  size="lg" 
                  variant="outline" 
                  className="w-full sm:w-auto bg-primary-foreground/10 hover:bg-primary-foreground/20 border-primary-foreground/20"
                  data-testid="button-cta-browse"
                >
                  Parcourir les besoins
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 border-t bg-card">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Heart className="h-5 w-5 text-primary" />
                <span className="font-semibold" style={{ fontFamily: "Poppins, sans-serif" }}>
                  HederaSoutien
                </span>
              </div>
              <p className="text-sm text-muted-foreground">
                Une plateforme de solidarité transparente et accessible pour tous.
              </p>
            </div>
            
            <div>
              <h3 className="font-semibold mb-4">Plateforme</h3>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><Link href="/requests" data-testid="link-footer-requests">Demandes d'aide</Link></li>
                <li><Link href="/equipment" data-testid="link-footer-equipment">Équipements</Link></li>
                <li><Link href="/volunteer" data-testid="link-footer-volunteer">Bénévolat</Link></li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-semibold mb-4">Ressources</h3>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#comment-ca-marche">Comment ça marche</a></li>
                <li><a href="#fonctionnalites">Fonctionnalités</a></li>
                <li><a href="#impact">Notre impact</a></li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-semibold mb-4">Technologie</h3>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>Hedera Blockchain</li>
                <li>NFT Recognition</li>
                <li>Transparence totale</li>
              </ul>
            </div>
          </div>
          
          <div className="mt-12 pt-8 border-t text-center text-sm text-muted-foreground">
            <p>© 2025 HederaSoutien. Tous droits réservés. Propulsé par Hedera.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
