# HederaSoutien - Plateforme de Solidarité Accessible

## Vue d'ensemble
HederaSoutien (anciennement SoutienHandi) est une plateforme de solidarité complète qui connecte les personnes en situation de handicap avec les donateurs, bénévoles et associations. La plateforme utilise la blockchain Hedera pour assurer la transparence des dons et un système de NFT pour la reconnaissance des donateurs et le registre d'équipements.

## Caractéristiques principales

### 1. Multi-types d'utilisateurs
- **Bénéficiaires** : Personnes en situation de handicap qui peuvent créer des demandes d'assistance
- **Donateurs** : Personnes qui font des dons et reçoivent des badges NFT de reconnaissance
- **Bénévoles** : Personnes qui offrent leur temps et compétences
- **Associations** : Organisations qui créent des opportunités de bénévolat

### 2. Intégration Blockchain Hedera
- Tous les dons sont enregistrés sur Hedera Testnet pour une transparence totale
- Chaque utilisateur reçoit automatiquement un wallet Hedera lors de l'inscription
- Les transactions sont vérifiables via HashScan
- NFTs pour les badges de donateurs (Bronze, Silver, Gold, Diamond, Legendary)
- NFTs pour le registre d'équipements médicaux

### 3. Accessibilité WCAG 2.1 AA
- Navigation clavier complète
- Support pour lecteurs d'écran
- Contrôle de la taille de police
- Mode de contraste élevé
- data-testid sur tous les éléments interactifs

### 4. Fonctionnalités principales
- Demandes d'assistance avec objectifs de financement
- Système de messagerie entre utilisateurs
- Registre d'équipements partagés avec historique de transfert
- Opportunités de bénévolat
- Statistiques globales d'impact

## Architecture technique

### Backend
- **Framework** : Express.js avec TypeScript
- **Base de données** : PostgreSQL (Neon)
- **ORM** : Drizzle
- **Authentification** : Replit Auth (OpenID Connect)
- **Blockchain** : Hedera SDK (@hashgraph/sdk)
- **Session** : connect-pg-simple (PostgreSQL session store)

### Frontend
- **Framework** : React avec TypeScript
- **Routing** : Wouter
- **State Management** : TanStack Query (React Query)
- **UI Components** : Shadcn/ui (Radix UI)
- **Styling** : Tailwind CSS
- **Fonts** : Inter (body), Poppins (headlines)

### Schema de base de données

**Tables principales :**
- `sessions` - Stockage des sessions utilisateur (requis pour Replit Auth)
- `users` - Informations utilisateur de base (compatible Replit Auth)
- `profiles` - Profils étendus avec wallet Hedera
- `assistance_requests` - Demandes d'aide des bénéficiaires
- `donations` - Historique des dons avec transactions Hedera
- `equipment` - Registre d'équipements avec NFTs
- `equipment_transfers` - Historique des transferts d'équipements
- `nft_badges` - Badges NFT de reconnaissance pour donateurs
- `messages` - Système de messagerie
- `volunteer_opportunities` - Opportunités de bénévolat
- `volunteer_assignments` - Assignations de bénévoles

### Variables d'environnement requises
```
DATABASE_URL - URL de connexion PostgreSQL
SESSION_SECRET - Secret pour les sessions
HEDERA_OPERATOR_ID - ID du compte opérateur Hedera
HEDERA_OPERATOR_KEY - Clé privée du compte opérateur
HEDERA_NETWORK - Réseau Hedera (testnet/mainnet)
REPL_ID - ID du Repl (fourni par Replit)
REPLIT_DOMAINS - Domaines autorisés (fourni par Replit)
ISSUER_URL - URL de l'émetteur OIDC (optionnel, défaut: https://replit.com/oidc)
```

## Design System

### Couleurs
- **Primary** : Bleu (202, 85%, 42%) - Confiance, professionnalisme
- **Secondary** : Gris neutre pour le contenu secondaire
- **Destructive** : Rouge pour les actions critiques
- **Background** : Blanc/Gris très clair (mode clair), Gris foncé (mode sombre)

### Typographie
- **Body** : Inter (400, 500, 600, 700) - Lisibilité exceptionnelle
- **Headlines** : Poppins (600, 700) - Impact émotionnel
- **Line height** : relaxed (1.625) pour meilleure lisibilité

### Spacing
- Petite : 16-24px (p-4 à p-6)
- Moyenne : 32-48px (p-8 à p-12)
- Grande : 64-96px (p-16 à p-24)

## Développement

### Commandes disponibles
```bash
npm run dev          # Démarrer le serveur de développement
npm run db:push      # Synchroniser le schéma avec la base de données
npm run db:studio    # Ouvrir Drizzle Studio
```

### Workflow de développement
1. Les modifications au schéma doivent être faites dans `shared/schema.ts`
2. Exécuter `npm run db:push` pour synchroniser avec la base de données
3. Mettre à jour l'interface IStorage dans `server/storage.ts`
4. Créer les routes API dans `server/routes.ts`
5. Créer les composants frontend dans `client/src/pages/`

### Structure des fichiers
```
server/
  ├── db.ts              # Configuration Drizzle
  ├── storage.ts         # Interface et implémentation du stockage
  ├── routes.ts          # Routes API Express
  ├── replitAuth.ts      # Configuration Replit Auth
  ├── hedera.ts          # Service Hedera blockchain
  └── index.ts           # Point d'entrée serveur

client/src/
  ├── pages/             # Pages de l'application
  ├── components/        # Composants réutilisables (Shadcn)
  ├── hooks/             # Hooks React personnalisés
  ├── lib/               # Utilitaires
  └── index.css          # Styles globaux et variables CSS

shared/
  └── schema.ts          # Schéma Drizzle et types TypeScript
```

## Principe de design : "Dignity through design"

La plateforme est conçue avec le principe fondamental de **dignité par le design** :
- Éviter toute imagerie inspirant la pitié
- Utiliser des visuels qui montrent l'autonomisation et l'espoir
- Traiter tous les utilisateurs avec respect
- Mettre l'accent sur les capacités plutôt que les limitations
- Design inclusif qui bénéficie à tous

## Roadmap future

### Phase 1 (MVP - Actuelle)
✓ Authentication Replit Auth
✓ Gestion des profils utilisateurs
✓ Demandes d'assistance
✓ Système de dons avec Hedera
✓ Badges NFT de reconnaissance
✓ Page d'accueil

### Phase 2
- Dashboard bénéficiaire complet
- Dashboard donateur avec galerie NFT
- Dashboard bénévole
- Système de messagerie en temps réel
- Registre d'équipements avec transferts NFT

### Phase 3
- Notifications en temps réel
- Système de recherche avancé
- Filtres et tri par catégorie/urgence/localisation
- Rapports d'impact détaillés
- Export des données de transparence

### Phase 4
- Application mobile (React Native)
- Support multilingue
- Intégration avec associations partenaires
- Programme d'ambassadeurs
- Migration vers Hedera Mainnet

## Conformité et sécurité

### WCAG 2.1 AA
- Contraste minimum de 4.5:1 pour le texte normal
- Contraste minimum de 3:1 pour le texte large
- Navigation clavier complète
- Support ARIA
- Focus visible sur tous les éléments interactifs

### Sécurité
- Sessions sécurisées avec PostgreSQL store
- HTTPS obligatoire en production
- Cookies HttpOnly et Secure
- Validation Zod pour toutes les entrées
- Protection CSRF via express-session
- Gestion sécurisée des clés privées Hedera

## Support et contribution

Le projet suit les meilleures pratiques de développement fullstack JavaScript :
- TypeScript strict pour la sécurité des types
- Validation de schéma avec Zod
- Gestion d'état avec TanStack Query
- Components UI accessibles avec Shadcn
- Design system cohérent avec Tailwind

## Notes importantes

1. **Hedera Testnet** : Le projet utilise actuellement Hedera Testnet. Les transactions sont gratuites et aucun argent réel n'est impliqué.

2. **Replit Auth** : L'authentification est gérée par Replit Auth (OpenID Connect), supportant Google, GitHub, X, Apple et email/password.

3. **Base de données** : PostgreSQL est utilisé pour la persistance avec Drizzle ORM. Les sessions sont stockées dans la base de données pour la scalabilité.

4. **Accessibilité** : Tous les composants ont des data-testid pour faciliter les tests et l'accessibilité est une priorité absolue (WCAG 2.1 AA).
