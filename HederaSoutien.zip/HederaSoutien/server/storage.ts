import { eq, desc, and, sql } from "drizzle-orm";
import { db } from "./db";
import * as schema from "@shared/schema";
import type {
  User,
  UpsertUser,
  InsertUser,
  Profile,
  InsertProfile,
  AssistanceRequest,
  InsertAssistanceRequest,
  Donation,
  InsertDonation,
  Equipment,
  InsertEquipment,
  Message,
  InsertMessage,
  VolunteerOpportunity,
  InsertVolunteerOpportunity,
  VolunteerAssignment,
  InsertVolunteerAssignment,
  NFTBadge,
  EquipmentTransfer,
} from "@shared/schema";

export interface IStorage {
  // Users (Replit Auth compatible)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Profiles
  getProfile(userId: string): Promise<Profile | undefined>;
  getProfileByUserId(userId: string): Promise<Profile | undefined>;
  createProfile(profile: InsertProfile): Promise<Profile>;
  updateProfile(userId: string, profile: Partial<Profile>): Promise<Profile | undefined>;
  
  // Assistance Requests
  getAssistanceRequest(id: string): Promise<AssistanceRequest | undefined>;
  getAllAssistanceRequests(status?: string): Promise<AssistanceRequest[]>;
  getAssistanceRequestsByBeneficiary(beneficiaryId: string): Promise<AssistanceRequest[]>;
  createAssistanceRequest(request: InsertAssistanceRequest): Promise<AssistanceRequest>;
  updateAssistanceRequest(id: string, request: Partial<AssistanceRequest>): Promise<AssistanceRequest | undefined>;
  
  // Donations
  getDonation(id: string): Promise<Donation | undefined>;
  getDonationsByDonor(donorId: string): Promise<Donation[]>;
  getDonationsByRequest(requestId: string): Promise<Donation[]>;
  createDonation(donation: InsertDonation): Promise<Donation>;
  
  // Equipment
  getEquipment(id: string): Promise<Equipment | undefined>;
  getAllEquipment(): Promise<Equipment[]>;
  getEquipmentByOwner(ownerId: string): Promise<Equipment[]>;
  createEquipment(equipment: InsertEquipment): Promise<Equipment>;
  updateEquipment(id: string, equipment: Partial<Equipment>): Promise<Equipment | undefined>;
  
  // Equipment Transfers
  createEquipmentTransfer(transfer: {
    equipmentId: string;
    fromUserId: string;
    toUserId: string;
    hederaTransactionId?: string;
    notes?: string;
  }): Promise<EquipmentTransfer>;
  getEquipmentTransfers(equipmentId: string): Promise<EquipmentTransfer[]>;
  
  // NFT Badges
  getNFTBadgesByUser(userId: string): Promise<NFTBadge[]>;
  createNFTBadge(badge: {
    userId: string;
    tier: "bronze" | "silver" | "gold" | "diamond" | "legendary";
    name: string;
    description: string;
    imageUrl: string;
    nftTokenId?: string;
    nftSerialNumber?: string;
    metadata?: string;
  }): Promise<NFTBadge>;
  
  // Messages
  getMessage(id: string): Promise<Message | undefined>;
  getMessagesBetweenUsers(userId1: string, userId2: string): Promise<Message[]>;
  getMessagesForUser(userId: string): Promise<Message[]>;
  createMessage(message: InsertMessage): Promise<Message>;
  markMessageAsRead(id: string): Promise<void>;
  
  // Volunteer Opportunities
  getVolunteerOpportunity(id: string): Promise<VolunteerOpportunity | undefined>;
  getAllVolunteerOpportunities(): Promise<VolunteerOpportunity[]>;
  createVolunteerOpportunity(opportunity: InsertVolunteerOpportunity): Promise<VolunteerOpportunity>;
  
  // Volunteer Assignments
  createVolunteerAssignment(assignment: InsertVolunteerAssignment): Promise<VolunteerAssignment>;
  getVolunteerAssignmentsByVolunteer(volunteerId: string): Promise<VolunteerAssignment[]>;
  updateVolunteerAssignment(id: string, assignment: Partial<VolunteerAssignment>): Promise<VolunteerAssignment | undefined>;
  
  // Statistics
  getGlobalStats(): Promise<{
    totalUsers: number;
    totalDonations: number;
    totalDonated: number;
    activeRequests: number;
    equipmentShared: number;
  }>;
}

export class DbStorage implements IStorage {
  // Users (Replit Auth compatible)
  async getUser(id: string): Promise<User | undefined> {
    const result = await db.select().from(schema.users).where(eq(schema.users.id, id));
    return result[0];
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(schema.users)
      .values(userData)
      .onConflictDoUpdate({
        target: schema.users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Profiles
  async getProfile(userId: string): Promise<Profile | undefined> {
    const result = await db.select().from(schema.profiles).where(eq(schema.profiles.userId, userId));
    return result[0];
  }

  async getProfileByUserId(userId: string): Promise<Profile | undefined> {
    return this.getProfile(userId);
  }

  async createProfile(profile: InsertProfile): Promise<Profile> {
    const result = await db.insert(schema.profiles).values(profile).returning();
    return result[0];
  }

  async updateProfile(userId: string, profileUpdate: Partial<Profile>): Promise<Profile | undefined> {
    const result = await db
      .update(schema.profiles)
      .set(profileUpdate)
      .where(eq(schema.profiles.userId, userId))
      .returning();
    return result[0];
  }

  // Assistance Requests
  async getAssistanceRequest(id: string): Promise<AssistanceRequest | undefined> {
    const result = await db.select().from(schema.assistanceRequests).where(eq(schema.assistanceRequests.id, id));
    return result[0];
  }

  async getAllAssistanceRequests(status?: string): Promise<AssistanceRequest[]> {
    if (status) {
      return await db
        .select()
        .from(schema.assistanceRequests)
        .where(eq(schema.assistanceRequests.status, status as any))
        .orderBy(desc(schema.assistanceRequests.createdAt));
    }
    return await db.select().from(schema.assistanceRequests).orderBy(desc(schema.assistanceRequests.createdAt));
  }

  async getAssistanceRequestsByBeneficiary(beneficiaryId: string): Promise<AssistanceRequest[]> {
    return await db
      .select()
      .from(schema.assistanceRequests)
      .where(eq(schema.assistanceRequests.beneficiaryId, beneficiaryId))
      .orderBy(desc(schema.assistanceRequests.createdAt));
  }

  async createAssistanceRequest(request: InsertAssistanceRequest): Promise<AssistanceRequest> {
    const result = await db.insert(schema.assistanceRequests).values(request).returning();
    return result[0];
  }

  async updateAssistanceRequest(id: string, requestUpdate: Partial<AssistanceRequest>): Promise<AssistanceRequest | undefined> {
    const result = await db
      .update(schema.assistanceRequests)
      .set({ ...requestUpdate, updatedAt: new Date() })
      .where(eq(schema.assistanceRequests.id, id))
      .returning();
    return result[0];
  }

  // Donations
  async getDonation(id: string): Promise<Donation | undefined> {
    const result = await db.select().from(schema.donations).where(eq(schema.donations.id, id));
    return result[0];
  }

  async getDonationsByDonor(donorId: string): Promise<Donation[]> {
    return await db
      .select()
      .from(schema.donations)
      .where(eq(schema.donations.donorId, donorId))
      .orderBy(desc(schema.donations.createdAt));
  }

  async getDonationsByRequest(requestId: string): Promise<Donation[]> {
    return await db
      .select()
      .from(schema.donations)
      .where(eq(schema.donations.requestId, requestId))
      .orderBy(desc(schema.donations.createdAt));
  }

  async createDonation(donation: InsertDonation): Promise<Donation> {
    const result = await db.insert(schema.donations).values(donation).returning();
    return result[0];
  }

  // Equipment
  async getEquipment(id: string): Promise<Equipment | undefined> {
    const result = await db.select().from(schema.equipment).where(eq(schema.equipment.id, id));
    return result[0];
  }

  async getAllEquipment(): Promise<Equipment[]> {
    return await db.select().from(schema.equipment).orderBy(desc(schema.equipment.createdAt));
  }

  async getEquipmentByOwner(ownerId: string): Promise<Equipment[]> {
    return await db
      .select()
      .from(schema.equipment)
      .where(eq(schema.equipment.ownerId, ownerId))
      .orderBy(desc(schema.equipment.createdAt));
  }

  async createEquipment(equipment: InsertEquipment): Promise<Equipment> {
    const result = await db.insert(schema.equipment).values(equipment).returning();
    return result[0];
  }

  async updateEquipment(id: string, equipmentUpdate: Partial<Equipment>): Promise<Equipment | undefined> {
    const result = await db
      .update(schema.equipment)
      .set(equipmentUpdate)
      .where(eq(schema.equipment.id, id))
      .returning();
    return result[0];
  }

  // Equipment Transfers
  async createEquipmentTransfer(transfer: {
    equipmentId: string;
    fromUserId: string;
    toUserId: string;
    hederaTransactionId?: string;
    notes?: string;
  }): Promise<EquipmentTransfer> {
    const result = await db.insert(schema.equipmentTransfers).values(transfer).returning();
    return result[0];
  }

  async getEquipmentTransfers(equipmentId: string): Promise<EquipmentTransfer[]> {
    return await db
      .select()
      .from(schema.equipmentTransfers)
      .where(eq(schema.equipmentTransfers.equipmentId, equipmentId))
      .orderBy(desc(schema.equipmentTransfers.transferDate));
  }

  // NFT Badges
  async getNFTBadgesByUser(userId: string): Promise<NFTBadge[]> {
    return await db
      .select()
      .from(schema.nftBadges)
      .where(eq(schema.nftBadges.userId, userId))
      .orderBy(desc(schema.nftBadges.achievementDate));
  }

  async createNFTBadge(badge: {
    userId: string;
    tier: "bronze" | "silver" | "gold" | "diamond" | "legendary";
    name: string;
    description: string;
    imageUrl: string;
    nftTokenId?: string;
    nftSerialNumber?: string;
    metadata?: string;
  }): Promise<NFTBadge> {
    const result = await db.insert(schema.nftBadges).values(badge).returning();
    return result[0];
  }

  // Messages
  async getMessage(id: string): Promise<Message | undefined> {
    const result = await db.select().from(schema.messages).where(eq(schema.messages.id, id));
    return result[0];
  }

  async getMessagesBetweenUsers(userId1: string, userId2: string): Promise<Message[]> {
    return await db
      .select()
      .from(schema.messages)
      .where(
        and(
          sql`(${schema.messages.senderId} = ${userId1} AND ${schema.messages.recipientId} = ${userId2}) OR (${schema.messages.senderId} = ${userId2} AND ${schema.messages.recipientId} = ${userId1})`
        )
      )
      .orderBy(schema.messages.createdAt);
  }

  async getMessagesForUser(userId: string): Promise<Message[]> {
    return await db
      .select()
      .from(schema.messages)
      .where(
        sql`${schema.messages.senderId} = ${userId} OR ${schema.messages.recipientId} = ${userId}`
      )
      .orderBy(desc(schema.messages.createdAt));
  }

  async createMessage(message: InsertMessage): Promise<Message> {
    const result = await db.insert(schema.messages).values(message).returning();
    return result[0];
  }

  async markMessageAsRead(id: string): Promise<void> {
    await db.update(schema.messages).set({ isRead: true }).where(eq(schema.messages.id, id));
  }

  // Volunteer Opportunities
  async getVolunteerOpportunity(id: string): Promise<VolunteerOpportunity | undefined> {
    const result = await db.select().from(schema.volunteerOpportunities).where(eq(schema.volunteerOpportunities.id, id));
    return result[0];
  }

  async getAllVolunteerOpportunities(): Promise<VolunteerOpportunity[]> {
    return await db
      .select()
      .from(schema.volunteerOpportunities)
      .where(eq(schema.volunteerOpportunities.isActive, true))
      .orderBy(desc(schema.volunteerOpportunities.createdAt));
  }

  async createVolunteerOpportunity(opportunity: InsertVolunteerOpportunity): Promise<VolunteerOpportunity> {
    const result = await db.insert(schema.volunteerOpportunities).values(opportunity).returning();
    return result[0];
  }

  // Volunteer Assignments
  async createVolunteerAssignment(assignment: InsertVolunteerAssignment): Promise<VolunteerAssignment> {
    const result = await db.insert(schema.volunteerAssignments).values(assignment).returning();
    return result[0];
  }

  async getVolunteerAssignmentsByVolunteer(volunteerId: string): Promise<VolunteerAssignment[]> {
    return await db
      .select()
      .from(schema.volunteerAssignments)
      .where(eq(schema.volunteerAssignments.volunteerId, volunteerId))
      .orderBy(desc(schema.volunteerAssignments.createdAt));
  }

  async updateVolunteerAssignment(id: string, assignmentUpdate: Partial<VolunteerAssignment>): Promise<VolunteerAssignment | undefined> {
    const result = await db
      .update(schema.volunteerAssignments)
      .set(assignmentUpdate)
      .where(eq(schema.volunteerAssignments.id, id))
      .returning();
    return result[0];
  }

  // Statistics
  async getGlobalStats(): Promise<{
    totalUsers: number;
    totalDonations: number;
    totalDonated: number;
    activeRequests: number;
    equipmentShared: number;
  }> {
    const [usersCount] = await db.select({ count: sql<number>`cast(count(*) as int)` }).from(schema.users);
    const [donationsCount] = await db.select({ count: sql<number>`cast(count(*) as int)` }).from(schema.donations);
    const [donatedSum] = await db.select({ sum: sql<number>`cast(coalesce(sum(${schema.donations.amount}), 0) as int)` }).from(schema.donations);
    const [requestsCount] = await db
      .select({ count: sql<number>`cast(count(*) as int)` })
      .from(schema.assistanceRequests)
      .where(eq(schema.assistanceRequests.status, "active"));
    const [equipmentCount] = await db.select({ count: sql<number>`cast(count(*) as int)` }).from(schema.equipment);

    return {
      totalUsers: usersCount.count || 0,
      totalDonations: donationsCount.count || 0,
      totalDonated: donatedSum.sum || 0,
      activeRequests: requestsCount.count || 0,
      equipmentShared: equipmentCount.count || 0,
    };
  }
}

export const storage = new DbStorage();
