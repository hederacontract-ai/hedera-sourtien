import {
  Client,
  AccountId,
  PrivateKey,
  AccountCreateTransaction,
  Hbar,
  TransferTransaction,
  TokenCreateTransaction,
  TokenType,
  TokenSupplyType,
  TokenMintTransaction,
  TransferTransaction as TokenTransferTransaction,
} from "@hashgraph/sdk";

// Initialize Hedera client
export function createHederaClient(): Client {
  const operatorId = AccountId.fromString(process.env.HEDERA_OPERATOR_ID!);
  const operatorKey = PrivateKey.fromStringED25519(process.env.HEDERA_OPERATOR_KEY!);
  
  let client: Client;
  
  if (process.env.HEDERA_NETWORK === "testnet") {
    client = Client.forTestnet();
  } else {
    client = Client.forMainnet();
  }
  
  client.setOperator(operatorId, operatorKey);
  
  return client;
}

export const hederaClient = createHederaClient();

// Create a new Hedera account for a user
export async function createUserAccount(): Promise<{
  accountId: string;
  publicKey: string;
  privateKey: string;
}> {
  try {
    const newAccountPrivateKey = PrivateKey.generateED25519();
    const newAccountPublicKey = newAccountPrivateKey.publicKey;

    const newAccount = await new AccountCreateTransaction()
      .setKey(newAccountPublicKey)
      .setInitialBalance(Hbar.fromTinybars(1000)) // Small initial balance
      .execute(hederaClient);

    const getReceipt = await newAccount.getReceipt(hederaClient);
    const newAccountId = getReceipt.accountId;

    if (!newAccountId) {
      throw new Error("Failed to create Hedera account");
    }

    return {
      accountId: newAccountId.toString(),
      publicKey: newAccountPublicKey.toString(),
      privateKey: newAccountPrivateKey.toString(),
    };
  } catch (error) {
    console.error("Error creating Hedera account:", error);
    throw error;
  }
}

// Transfer HBAR (donation transaction)
export async function transferHbar(
  fromAccountId: string,
  fromPrivateKey: string,
  toAccountId: string,
  amount: number, // in cents
): Promise<{
  transactionId: string;
  transactionUrl: string;
}> {
  try {
    // Convert cents to HBAR (1 HBAR = 100 cents for demo purposes)
    const hbarAmount = amount / 100;

    // Create a temporary client with the donor's key
    const donorKey = PrivateKey.fromStringED25519(fromPrivateKey);
    const donorClient = createHederaClient();
    donorClient.setOperator(fromAccountId, donorKey);

    const transaction = await new TransferTransaction()
      .addHbarTransfer(fromAccountId, Hbar.from(-hbarAmount))
      .addHbarTransfer(toAccountId, Hbar.from(hbarAmount))
      .execute(donorClient);

    const receipt = await transaction.getReceipt(donorClient);
    
    if (receipt.status.toString() !== "SUCCESS") {
      throw new Error("Transaction failed");
    }

    const transactionId = transaction.transactionId.toString();
    const network = process.env.HEDERA_NETWORK || "testnet";
    const transactionUrl = `https://hashscan.io/${network}/transaction/${transactionId}`;

    return {
      transactionId,
      transactionUrl,
    };
  } catch (error) {
    console.error("Error transferring HBAR:", error);
    throw error;
  }
}

// Create NFT token (for badges or equipment)
export async function createNFTToken(
  name: string,
  symbol: string,
): Promise<string> {
  try {
    const transaction = await new TokenCreateTransaction()
      .setTokenName(name)
      .setTokenSymbol(symbol)
      .setTokenType(TokenType.NonFungibleUnique)
      .setDecimals(0)
      .setInitialSupply(0)
      .setTreasuryAccountId(hederaClient.operatorAccountId!)
      .setSupplyType(TokenSupplyType.Infinite)
      .setSupplyKey(hederaClient.operatorPublicKey!)
      .execute(hederaClient);

    const receipt = await transaction.getReceipt(hederaClient);
    const tokenId = receipt.tokenId;

    if (!tokenId) {
      throw new Error("Failed to create NFT token");
    }

    return tokenId.toString();
  } catch (error) {
    console.error("Error creating NFT token:", error);
    throw error;
  }
}

// Mint NFT
export async function mintNFT(
  tokenId: string,
  metadata: string, // JSON metadata as string
): Promise<string> {
  try {
    const mintTx = await new TokenMintTransaction()
      .setTokenId(tokenId)
      .setMetadata([Buffer.from(metadata)])
      .execute(hederaClient);

    const receipt = await mintTx.getReceipt(hederaClient);
    const serialNumbers = receipt.serials;

    if (!serialNumbers || serialNumbers.length === 0) {
      throw new Error("Failed to mint NFT");
    }

    return serialNumbers[0].toString();
  } catch (error) {
    console.error("Error minting NFT:", error);
    throw error;
  }
}

// Get donor badge tier based on total donated amount
export function getDonorBadgeTier(totalDonated: number): {
  tier: "bronze" | "silver" | "gold" | "diamond" | "legendary";
  name: string;
  description: string;
} {
  // Amounts in cents
  if (totalDonated >= 100000) { // €1000+
    return {
      tier: "legendary",
      name: "Bienfaiteur Légendaire",
      description: "Plus de 1000€ de dons - Impact extraordinaire",
    };
  } else if (totalDonated >= 50000) { // €500+
    return {
      tier: "diamond",
      name: "Bienfaiteur Diamant",
      description: "Plus de 500€ de dons - Générosité exceptionnelle",
    };
  } else if (totalDonated >= 20000) { // €200+
    return {
      tier: "gold",
      name: "Bienfaiteur Or",
      description: "Plus de 200€ de dons - Soutien précieux",
    };
  } else if (totalDonated >= 5000) { // €50+
    return {
      tier: "silver",
      name: "Bienfaiteur Argent",
      description: "Plus de 50€ de dons - Solidarité active",
    };
  } else {
    return {
      tier: "bronze",
      name: "Bienfaiteur Bronze",
      description: "Premier don - Merci pour votre soutien",
    };
  }
}
