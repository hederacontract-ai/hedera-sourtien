import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { 
  insertProfileSchema, 
  insertAssistanceRequestSchema, 
  insertDonationSchema,
  insertEquipmentSchema,
  insertMessageSchema,
  insertVolunteerOpportunitySchema,
  insertVolunteerAssignmentSchema,
} from "@shared/schema";
import { createUserAccount, transferHbar, getDonorBadgeTier } from "./hedera";
import { encrypt, decrypt } from "./crypto";

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup Replit Auth
  await setupAuth(app);
  
  // Auth route
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });
  
  // ============= Profile Routes =============
  
  // Get current user's profile
  app.get("/api/profile", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const profile = await storage.getProfile(userId);
      if (!profile) {
        return res.status(404).send("Profile not found");
      }
      // Exclude sensitive Hedera private key from response
      const { hederaPrivateKey, ...safeProfile } = profile;
      res.json(safeProfile);
    } catch (error) {
      console.error("Error fetching profile:", error);
      res.status(500).send("Error fetching profile");
    }
  });
  
  // Create or update profile
  app.post("/api/profile", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const validatedData = insertProfileSchema.parse({
        ...req.body,
        userId,
      });
      
      const existingProfile = await storage.getProfile(userId);
      
      if (existingProfile) {
        const updated = await storage.updateProfile(userId, validatedData);
        return res.json(updated);
      }
      
      // Create Hedera account for new user
      const hederaAccount = await createUserAccount();
      
      const profile = await storage.createProfile({
        ...validatedData,
        hederaAccountId: hederaAccount.accountId,
        hederaPublicKey: hederaAccount.publicKey,
        hederaPrivateKey: encrypt(hederaAccount.privateKey), // Store encrypted
      });
      
      res.json(profile);
    } catch (error) {
      console.error("Error creating/updating profile:", error);
      res.status(500).send("Error saving profile");
    }
  });
  
  // Get profile by user ID (protected - only own profile with sensitive data)
  app.get("/api/profile/:userId", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const requestedUserId = req.params.userId;
      
      const profile = await storage.getProfile(requestedUserId);
      if (!profile) {
        return res.status(404).send("Profile not found");
      }
      
      // If requesting own profile, return full data (except private key)
      // If requesting someone else's, return only public data
      if (requestedUserId === userId) {
        // Own profile - exclude sensitive Hedera private key
        const { hederaPrivateKey, ...safeProfile } = profile;
        res.json(safeProfile);
      } else {
        // Public profile - only safe public data
        res.json({
          id: profile.id,
          userId: profile.userId,
          fullName: profile.fullName,
          avatarUrl: profile.avatarUrl,
          bio: profile.bio,
          location: profile.location,
          organizationName: profile.organizationName,
          totalDonated: profile.totalDonated,
          donationCount: profile.donationCount,
          hoursLogged: profile.hoursLogged,
        });
      }
    } catch (error) {
      console.error("Error fetching profile:", error);
      res.status(500).send("Error fetching profile");
    }
  });
  
  // ============= Assistance Request Routes =============
  
  // Get all assistance requests
  app.get("/api/requests", async (req, res) => {
    try {
      const status = req.query.status as string | undefined;
      const requests = await storage.getAllAssistanceRequests(status);
      res.json(requests);
    } catch (error) {
      console.error("Error fetching requests:", error);
      res.status(500).send("Error fetching requests");
    }
  });
  
  // Get single assistance request
  app.get("/api/requests/:id", async (req, res) => {
    try {
      const request = await storage.getAssistanceRequest(req.params.id);
      if (!request) {
        return res.status(404).send("Request not found");
      }
      res.json(request);
    } catch (error) {
      console.error("Error fetching request:", error);
      res.status(500).send("Error fetching request");
    }
  });
  
  // Get assistance requests by beneficiary (protected - only own requests)
  app.get("/api/requests/beneficiary/:beneficiaryId", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      
      // Users can only view their own requests
      if (req.params.beneficiaryId !== userId) {
        return res.status(403).send("Not authorized to view these requests");
      }
      
      const requests = await storage.getAssistanceRequestsByBeneficiary(req.params.beneficiaryId);
      res.json(requests);
    } catch (error) {
      console.error("Error fetching requests:", error);
      res.status(500).send("Error fetching requests");
    }
  });
  
  // Create assistance request
  app.post("/api/requests", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const validatedData = insertAssistanceRequestSchema.parse({
        ...req.body,
        beneficiaryId: userId,
      });
      
      const request = await storage.createAssistanceRequest(validatedData);
      res.json(request);
    } catch (error) {
      console.error("Error creating request:", error);
      res.status(500).send("Error creating request");
    }
  });
  
  // Update assistance request
  app.patch("/api/requests/:id", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const request = await storage.getAssistanceRequest(req.params.id);
      if (!request) {
        return res.status(404).send("Request not found");
      }
      
      if (request.beneficiaryId !== userId) {
        return res.status(403).send("Not authorized");
      }
      
      const updated = await storage.updateAssistanceRequest(req.params.id, req.body);
      res.json(updated);
    } catch (error) {
      console.error("Error updating request:", error);
      res.status(500).send("Error updating request");
    }
  });
  
  // ============= Donation Routes =============
  
  // Get donations by donor (protected - only own donations)
  app.get("/api/donations/donor/:donorId", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      
      // Users can only view their own donations
      if (req.params.donorId !== userId) {
        return res.status(403).send("Not authorized to view these donations");
      }
      
      const donations = await storage.getDonationsByDonor(req.params.donorId);
      res.json(donations);
    } catch (error) {
      console.error("Error fetching donations:", error);
      res.status(500).send("Error fetching donations");
    }
  });
  
  // Get donations by request
  app.get("/api/donations/request/:requestId", async (req, res) => {
    try {
      const donations = await storage.getDonationsByRequest(req.params.requestId);
      res.json(donations);
    } catch (error) {
      console.error("Error fetching donations:", error);
      res.status(500).send("Error fetching donations");
    }
  });
  
  // Create donation
  app.post("/api/donations", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const validatedData = insertDonationSchema.parse({
        ...req.body,
        donorId: userId,
      });
      
      // Get donor and beneficiary profiles for Hedera accounts
      const donorProfile = await storage.getProfile(userId);
      const request = await storage.getAssistanceRequest(validatedData.requestId);
      
      if (!donorProfile || !request) {
        return res.status(404).send("Donor or request not found");
      }
      
      const beneficiaryProfile = await storage.getProfile(request.beneficiaryId);
      if (!beneficiaryProfile) {
        return res.status(404).send("Beneficiary profile not found");
      }
      
      // Transfer HBAR on Hedera blockchain
      let hederaTransaction;
      if (donorProfile.hederaAccountId && beneficiaryProfile.hederaAccountId && donorProfile.hederaPrivateKey) {
        try {
          const donorPrivateKey = decrypt(donorProfile.hederaPrivateKey);
          hederaTransaction = await transferHbar(
            donorProfile.hederaAccountId,
            donorPrivateKey,
            beneficiaryProfile.hederaAccountId,
            validatedData.amount
          );
        } catch (hederaError) {
          console.error("Hedera transaction failed:", hederaError);
          // Return error to client instead of swallowing it
          return res.status(500).json({ 
            message: "Blockchain transaction failed", 
            error: hederaError instanceof Error ? hederaError.message : "Unknown error" 
          });
        }
      }
      
      // Create donation record
      const donation = await storage.createDonation({
        ...validatedData,
        hederaTransactionId: hederaTransaction?.transactionId,
        hederaTransactionUrl: hederaTransaction?.transactionUrl,
      });
      
      // Update request funding
      const newAmount = request.currentAmount + validatedData.amount;
      const newSupporterCount = request.supporterCount + 1;
      const newStatus = newAmount >= request.fundingGoal ? "funded" : request.status;
      
      await storage.updateAssistanceRequest(validatedData.requestId, {
        currentAmount: newAmount,
        supporterCount: newSupporterCount,
        status: newStatus as any,
      });
      
      // Update donor profile stats
      const newTotalDonated = (donorProfile.totalDonated || 0) + validatedData.amount;
      const newDonationCount = (donorProfile.donationCount || 0) + 1;
      
      await storage.updateProfile(userId, {
        totalDonated: newTotalDonated,
        donationCount: newDonationCount,
      });
      
      // Check if donor earned a new badge tier
      const badgeTier = getDonorBadgeTier(newTotalDonated);
      const existingBadges = await storage.getNFTBadgesByUser(userId);
      const hasBadge = existingBadges.some(b => b.tier === badgeTier.tier);
      
      if (!hasBadge) {
        await storage.createNFTBadge({
          userId,
          tier: badgeTier.tier,
          name: badgeTier.name,
          description: badgeTier.description,
          imageUrl: `/badges/${badgeTier.tier}.png`,
        });
      }
      
      res.json(donation);
    } catch (error) {
      console.error("Error creating donation:", error);
      res.status(500).send("Error creating donation");
    }
  });
  
  // ============= Equipment Routes =============
  
  // Get all equipment
  app.get("/api/equipment", async (req, res) => {
    try {
      const equipment = await storage.getAllEquipment();
      res.json(equipment);
    } catch (error) {
      console.error("Error fetching equipment:", error);
      res.status(500).send("Error fetching equipment");
    }
  });
  
  // Get equipment by owner (protected - only own equipment)
  app.get("/api/equipment/owner/:ownerId", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      
      // Users can only view their own equipment
      if (req.params.ownerId !== userId) {
        return res.status(403).send("Not authorized to view this equipment");
      }
      
      const equipment = await storage.getEquipmentByOwner(req.params.ownerId);
      res.json(equipment);
    } catch (error) {
      console.error("Error fetching equipment:", error);
      res.status(500).send("Error fetching equipment");
    }
  });
  
  // Get single equipment
  app.get("/api/equipment/:id", async (req, res) => {
    try {
      const equipment = await storage.getEquipment(req.params.id);
      if (!equipment) {
        return res.status(404).send("Equipment not found");
      }
      res.json(equipment);
    } catch (error) {
      console.error("Error fetching equipment:", error);
      res.status(500).send("Error fetching equipment");
    }
  });
  
  // Create equipment
  app.post("/api/equipment", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const validatedData = insertEquipmentSchema.parse({
        ...req.body,
        ownerId: userId,
      });
      
      const equipment = await storage.createEquipment(validatedData);
      res.json(equipment);
    } catch (error) {
      console.error("Error creating equipment:", error);
      res.status(500).send("Error creating equipment");
    }
  });
  
  // Get equipment transfer history
  app.get("/api/equipment/:id/transfers", async (req, res) => {
    try {
      const transfers = await storage.getEquipmentTransfers(req.params.id);
      res.json(transfers);
    } catch (error) {
      console.error("Error fetching transfers:", error);
      res.status(500).send("Error fetching transfers");
    }
  });
  
  // ============= NFT Badge Routes =============
  
  // Get NFT badges by user (protected - only own badges)
  app.get("/api/nft-badges/:userId", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      
      // Users can only view their own badges
      if (req.params.userId !== userId) {
        return res.status(403).send("Not authorized to view these badges");
      }
      
      const badges = await storage.getNFTBadgesByUser(req.params.userId);
      res.json(badges);
    } catch (error) {
      console.error("Error fetching badges:", error);
      res.status(500).send("Error fetching badges");
    }
  });
  
  // ============= Message Routes =============
  
  // Get messages for current user
  app.get("/api/messages", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const messages = await storage.getMessagesForUser(userId);
      res.json(messages);
    } catch (error) {
      console.error("Error fetching messages:", error);
      res.status(500).send("Error fetching messages");
    }
  });
  
  // Get messages between two users
  app.get("/api/messages/conversation/:otherUserId", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const messages = await storage.getMessagesBetweenUsers(userId, req.params.otherUserId);
      res.json(messages);
    } catch (error) {
      console.error("Error fetching messages:", error);
      res.status(500).send("Error fetching messages");
    }
  });
  
  // Send message
  app.post("/api/messages", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const validatedData = insertMessageSchema.parse({
        ...req.body,
        senderId: userId,
      });
      
      const message = await storage.createMessage(validatedData);
      res.json(message);
    } catch (error) {
      console.error("Error sending message:", error);
      res.status(500).send("Error sending message");
    }
  });
  
  // Mark message as read
  app.patch("/api/messages/:id/read", isAuthenticated, async (req: any, res) => {
    try {
      await storage.markMessageAsRead(req.params.id);
      res.json({ success: true });
    } catch (error) {
      console.error("Error marking message as read:", error);
      res.status(500).send("Error marking message as read");
    }
  });
  
  // ============= Volunteer Routes =============
  
  // Get all volunteer opportunities
  app.get("/api/volunteer-opportunities", async (req, res) => {
    try {
      const opportunities = await storage.getAllVolunteerOpportunities();
      res.json(opportunities);
    } catch (error) {
      console.error("Error fetching opportunities:", error);
      res.status(500).send("Error fetching opportunities");
    }
  });
  
  // Create volunteer opportunity
  app.post("/api/volunteer-opportunities", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const validatedData = insertVolunteerOpportunitySchema.parse({
        ...req.body,
        creatorId: userId,
      });
      
      const opportunity = await storage.createVolunteerOpportunity(validatedData);
      res.json(opportunity);
    } catch (error) {
      console.error("Error creating opportunity:", error);
      res.status(500).send("Error creating opportunity");
    }
  });
  
  // Get volunteer assignments (protected - only own assignments)
  app.get("/api/volunteer-assignments/:volunteerId", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      
      // Users can only view their own assignments
      if (req.params.volunteerId !== userId) {
        return res.status(403).send("Not authorized to view these assignments");
      }
      
      const assignments = await storage.getVolunteerAssignmentsByVolunteer(req.params.volunteerId);
      res.json(assignments);
    } catch (error) {
      console.error("Error fetching assignments:", error);
      res.status(500).send("Error fetching assignments");
    }
  });
  
  // Create volunteer assignment
  app.post("/api/volunteer-assignments", isAuthenticated, async (req: any, res) => {
    try {
      const validatedData = insertVolunteerAssignmentSchema.parse(req.body);
      const assignment = await storage.createVolunteerAssignment(validatedData);
      res.json(assignment);
    } catch (error) {
      console.error("Error creating assignment:", error);
      res.status(500).send("Error creating assignment");
    }
  });
  
  // Update volunteer assignment
  app.patch("/api/volunteer-assignments/:id", isAuthenticated, async (req: any, res) => {
    try {
      const updated = await storage.updateVolunteerAssignment(req.params.id, req.body);
      
      // If completed, update volunteer hours
      if (req.body.status === "completed" && req.body.hoursCompleted) {
        const assignment = await storage.updateVolunteerAssignment(req.params.id, {});
        if (assignment) {
          const profile = await storage.getProfile(assignment.volunteerId);
          if (profile) {
            const newHours = (profile.hoursLogged || 0) + (req.body.hoursCompleted || 0);
            await storage.updateProfile(assignment.volunteerId, {
              hoursLogged: newHours,
            });
          }
        }
      }
      
      res.json(updated);
    } catch (error) {
      console.error("Error updating assignment:", error);
      res.status(500).send("Error updating assignment");
    }
  });
  
  // ============= Statistics Routes =============
  
  // Get global statistics
  app.get("/api/stats", async (req, res) => {
    try {
      const stats = await storage.getGlobalStats();
      res.json(stats);
    } catch (error) {
      console.error("Error fetching stats:", error);
      res.status(500).send("Error fetching stats");
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
